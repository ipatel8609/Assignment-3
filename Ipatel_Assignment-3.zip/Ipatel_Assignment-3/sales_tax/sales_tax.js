function setCursor(){
    document.getElementById("subtotal").focus;
    }
var subtotal ,taxRate ,salesTax;
var total=0;
function setValues()
{
    subtotal=document.getElementById("subtotal").value;
    taxRate=document.getElementById("tax_rate").value;
    salesTax=document.getElementById("sales_tax").value;
    total=document.getElementById("total").value;
}
function calculate_click()
{
    setValues();
    if((subtotal<0)||(subtotal>10000))
    {
        alert("Subtotal must be > 0 and < 10000");
        document.getElementById("subtotal").focus;
    }
    else if((taxRate<0)||(taxRate>12)){
        alert("Tax Rate must be > 0 and < 12");
        document.getElementById("tax_rate").focus;

    }
    else{
    salesTax = subtotal * (taxRate/100);
    total = +salesTax + +subtotal;
    
    document.getElementById("sales_tax").value= salesTax;
    document.getElementById("total").value= total;
    }
}
function clear_click()
{
    document.getElementById("subtotal").value= "";
    document.getElementById("tax_rate").value= "";
    document.getElementById("sales_tax").value= "";
    document.getElementById("total").value= "";
    document.getElementById("subtotal").focus;
}