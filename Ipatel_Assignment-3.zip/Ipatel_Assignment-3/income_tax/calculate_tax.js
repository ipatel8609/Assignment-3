"use strict";
function processEntry() {
    var income = document.getElementById("income").value;

    if(income < 0) {
        alert("Amount should be greater than zero!");
        document.getElementById("income").focus();
    }

    else if((income > 0) && (income <= 9275)) {
        tempIncome = (income * 0.10);
        document.getElementById("tax").value = tempIncome;

    }

    else if((income > 9275) && (income <= 37650)) {
        tempIncome = ((income - 9275) * 0.15) + 927.5;
        document.getElementById("tax").value = tempIncome;
    }
}

window.onload = function () {
    $("calculate").onclick = processEntry;
}